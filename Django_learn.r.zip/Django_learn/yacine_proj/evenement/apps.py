from django.apps import AppConfig


class EvenementConfig(AppConfig):
    name = 'evenement'
