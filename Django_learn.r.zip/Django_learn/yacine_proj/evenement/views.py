from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader
from .forms import Form_Domaine,Form_question,Add_cours_Form,change
from django.contrib.auth import logout
from django.conf import settings 
from .models import Question_cours , Events_cours ,domaine
from django.contrib.auth import authenticate, login
from django.template.loader import get_template
import calendar
import datetime
from calendar import HTMLCalendar
from django.utils.safestring import mark_safe
from django.urls import reverse
from .utils import EventCalendar

def my_view(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        # Redirect to a success page.
        render(request , 'bootstrap/page_learn.html')
    else:
        # Return an 'invalid login' error message.
        render(request , 'bootstrap/page_learn.html')

def logout_view(request):
    logout(request)
    render(request , 'bootstrap/page_learn.html')


#----------------- the index view  -------------
def index_page(request): 

     form = Add_cours_Form(request.POST or None   )
     if form.is_valid() :
        print("ok the forms is valid ")
        form.save() 
     else : 
        print("no the cleaned data is not ok  ::::> "+str(form.errors))
 
     context = {
        'form' : form 
     }
    
     return render(request , 'bootstrap/page_learn.html',context)
#------------------ end of the view to add ------
# ------- --- - -  to add a domain 
def Add_domain(request):
    form = change()
    if request.method =="POST":
        form = change(request.POST)
    if form.is_valid(): 
       print(form.cleaned_data)
       domaine.objects.create(**form.cleaned_data)
    else:
        print(form.errors)   

    context = {
        'form' : form 
    }

    return render(request , 'bootstrap/Add_Domain.html',context)
#-----------------------------------------------------------------------------
def add_question_cours(request):
    print("......*****...> : "+str(settings.MEDIA_URL))
    form = Form_question()
    if request.method == "POST":
        form = Form_question(request.POST)

    if form.is_valid() :
        Question_cours.objects.create(**form.cleaned_data)
    else : 
        print(form.errors)
  
    context = { 'form' : form }
   
    return render(request , 'bootstrap/add_question.html',context)
#------------------------------------------------------------------------------
def get_nav_bar(request):
    return render(request ,'bootstrap/Nav_bar/nav_bar.html')    


def Calendar_print( request, context=None):
     after_day = request.GET.get('day__gte', None)
     context = context or {}
     if not after_day : 
        d = datetime.date.today() 
     
     else: 
         try:
             print("i am in the try"+str(after_day))
             split_after_day = after_day.split('-')
             d = datetime.date(year=int(split_after_day[0]), month=int(split_after_day[1]), day=1)
         except : 
             d = datetime.date.today()

     previous_month = datetime.date(year=d.year, month=d.month, day=1)
     previous_month = previous_month - datetime.timedelta(days=1)
     previous_month = datetime.date(year=previous_month.year, month=previous_month.month,
                                       day=1)
     last_day = calendar.monthrange(d.year, d.month)
     next_month = datetime.date(year=d.year, month=d.month, day=last_day[1])
     next_month = next_month + datetime.timedelta(days=1)  # forward a single day
     next_month = datetime.date(year=next_month.year, month=next_month.month,
                                   day=1)  # find first day of next month
     
     print("---->>--->> the after day is "+str(after_day))
     cal = EventCalendar()
     cal.cssclass_month_head = "text-center text-info border-top bg-dark"
     cal.cssclass_month = "col-md-12 "
     cal.cssclasses = ["mon text-bold", "tue", "wed", "thu", "fri", "sat", "sun red"]
     print("i am here ------------------------------")
     html_calendar = cal.formatmonth(d.year, d.month, withyear=True)
     html_calendar = html_calendar.replace('<td ', '<td  width="150" height="150" class="border shadow   p-3 mb-5 bg-white rounded  " ')
    
     context = { 
         'calendar':mark_safe(html_calendar ) ,
         'next_month' : reverse('Calendar_print') + '?day__gte=' + str(next_month)            ,
         'previous_month' : reverse('Calendar_print' )+'?day__gte=' + str(
            previous_month) 
     }
     return render(request , 'bootstrap/Calenda.html',context)

