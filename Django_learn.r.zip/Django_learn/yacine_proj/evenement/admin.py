from django.contrib import admin
from .models import Question_cours , domaine , Events_cours
admin.site.register(Question_cours)
admin.site.register(domaine)
admin.site.register(Events_cours)
# Register your models here.
