from calendar import HTMLCalendar 
from datetime import datetime as dtime , date , time 
import datetime 
from .models import Events_cours 
from django.http import HttpResponse
# import learn in 03 05 2019 ---> to load some data directly its use
from django.template import loader 
from django.template import * 

class EventCalendar(HTMLCalendar):
    def __init__(self,  events = None ):
        super(EventCalendar,self).__init__()
        self.events = events 
   
    def formatday(self , day , weekday , events ): 
        """
        Return a day as a table cell 
        """    
        events_from_day = events.filter(uploaded_at__day = day )
        events_html ="<ul>" 
        
        for event in events_from_day:
            events_html += event.get_absolute_url()+"<br>"
        events_html += "</ul>"

        if day == 0 :
            return '<td class = "noday"> &nbsp;</td>  '    
        else : 
            return '<td class ="%s">%d%s</td>'%(self.cssclasses[weekday],day,events_html)    

    def formatweek(self, theweek, events):
        """
        Return a complete week as a table row.
        """
        print("*************************************")
        s = ''.join(self.formatday(d, wd, events) for (d, wd) in theweek)
        
        return '<tr>%s</tr>' % s        
 
    def formatmonth(self, theyear, themonth, withyear=True):
        """
        Return a formatted month as a table.
        """
        t = loader.get_template('nav_bar.html')
        print("the answer is : "+str(t)) 
        print("the value tooooo T is : "+ str(t))
        events = Events_cours.objects.filter(uploaded_at__month=themonth)
        print("--q-q-SQ-Qs-SQ-sq-SQ-DSQ-DSQ-")
        v = []
        a = v.append
        print("--------------4545454")
        a('<div class ="container  ">')
        a('<table border="0" cellpadding="0" cellspacing="0" class="table table-striped">')
        a('\n')
        print("8================================>-----")    
        a(self.formatmonthname(theyear, themonth, withyear=withyear))
        print("8================================>-----") 
        a('\n')
        a(self.formatweekheader())
        i=1 
        a('\n')
        print(self.monthdays2calendar(theyear, themonth))
        print(events)
        for week in self.monthdays2calendar(theyear, themonth):
            a(self.formatweek(week, events))
            i=i+1
            a('\n')
        a('</table>')
        a('</div>')
        a('\n')
        return ''.join(v)     